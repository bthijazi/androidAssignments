package com.example.android1mid;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText num1, num2;
    TextView result;

    double value1, value2, res;
    String operation = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        result = findViewById(R.id.txtResult);

        Button add = findViewById(R.id.btnAdd);
        Button sub = findViewById(R.id.btnSub);
        Button mul = findViewById(R.id.btnMul);
        Button div = findViewById(R.id.btnDiv);

        add.setOnClickListener(v -> {
            calculate("ADD");
            result.setTextColor(Color.parseColor("#4CAF50"));
        });

        sub.setOnClickListener(v -> {
            calculate("SUB");
            result.setTextColor(Color.parseColor("#F44336"));
        });

        mul.setOnClickListener(v -> {
            calculate("MUL");
            result.setTextColor(Color.parseColor("#2196F3"));
        });

        div.setOnClickListener(v -> {
            calculate("DIV");
            result.setTextColor(Color.parseColor("#FF9800"));
        });

        // Clickable result → open second activity
        result.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ResultActivity.class);
            intent.putExtra("num1", value1);
            intent.putExtra("num2", value2);
            intent.putExtra("result", res);
            intent.putExtra("operation", operation);
            startActivity(intent);
        });

        // restore state
        if (savedInstanceState != null) {
            res = savedInstanceState.getDouble("result");
            operation = savedInstanceState.getString("op");
            result.setText("Result: " + res);
        }
    }

    private void calculate(String op) {

        value1 = Double.parseDouble(num1.getText().toString());
        value2 = Double.parseDouble(num2.getText().toString());

        operation = op;

        switch (op) {
            case "ADD": res = value1 + value2; break;
            case "SUB": res = value1 - value2; break;
            case "MUL": res = value1 * value2; break;
            case "DIV": res = value1 / value2; break;
        }

        result.setText("Result: " + res);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putDouble("result", res);
        outState.putString("op", operation);
    }
}
package com.example.android1mid;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
public class ResultActivity extends AppCompatActivity {

    TextView display;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        display = findViewById(R.id.txtDisplay);

        Intent intent = getIntent();

        double n1 = intent.getDoubleExtra("num1", 0);
        double n2 = intent.getDoubleExtra("num2", 0);
        double res = intent.getDoubleExtra("result", 0);
        String op = intent.getStringExtra("operation");

        display.setText(
                "Number 1: " + n1 +
                        "\nNumber 2: " + n2 +
                        "\nOperation: " + op +
                        "\nResult: " + res
        );
    }
}
